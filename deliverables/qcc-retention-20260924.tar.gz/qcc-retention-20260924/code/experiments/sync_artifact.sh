#!/usr/bin/env bash
# Copy the local report into the repo artifact, keeping the repo-path
# reproduction section.
set -eu
here="$(cd "$(dirname "$0")" && pwd)"
repo="$here/../../repo/qcc-transformer"
python - "$here" "$repo" <<'PY'
import sys
here, repo = sys.argv[1], sys.argv[2]
rep = open(f"{here}/REPORT.md").read()
repro = open(f"{here}/REPRO_REPO.md").read()
head = rep[: rep.index("## 8. Reproduction")]
open(f"{repo}/artifacts/bounded-decode-frontier-20260920.md", "w").write(head + repro)
print("synced artifact doc")
PY
