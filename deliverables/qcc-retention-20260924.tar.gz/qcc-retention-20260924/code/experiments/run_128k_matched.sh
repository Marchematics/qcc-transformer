#!/usr/bin/env bash
# Matched Full-KV vs bounded at 128K with the whole batch prefilled together.
set -u
cd /root/qcc/experiments/retention_frontier
source /root/qcc/venv/bin/activate
for _ in $(seq 1 900); do
  grep -q "\[s128\] done" s128_runner.log 2>/dev/null && break
  sleep 20
done
echo "[m128] start $(date -Is)"
python serve_batch.py --length 131072 --batches 1 2 4 \
  --policies full obs_last --budget 1024 --max-new 32 \
  --out serving_128k_matched.json > serving_128k_matched.log 2>&1
echo "[m128] done $(date -Is)"
