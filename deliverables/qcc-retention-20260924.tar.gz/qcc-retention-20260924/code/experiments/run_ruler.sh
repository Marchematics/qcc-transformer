#!/usr/bin/env bash
# Official RULER JSONL quality frontier, queued behind the synthetic expansion.
set -u
cd /root/qcc/experiments/retention_frontier
source /root/qcc/venv/bin/activate
while pgrep -f "[l]ongctx.py" > /dev/null; do sleep 20; done
echo "[runner] starting RULER frontier at $(date -Is)"
python ruler_frontier.py \
  --ruler-jsonl /home/waas/ruler_a10_v1/ruler_subset.jsonl \
  --tasks niah_single_1 niah_multikey_2 niah_multikey_3 vt \
  --policies full obs_last obs_mean \
  --budgets 128 256 1024 \
  --obs 64 --nsink 4 --pool 7 --max-new 32 --prefill-chunk 8192 \
  --out ruler_v1.json > ruler_v1.log 2>&1
echo "[runner] RULER frontier done at $(date -Is)"
