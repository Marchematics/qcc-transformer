#!/usr/bin/env bash
# Official RULER with sliding-window dilation and larger budgets, queued after
# the serving measurements.
set -u
cd /root/qcc/experiments/retention_frontier
source /root/qcc/venv/bin/activate
for _ in $(seq 1 900); do
  if grep -q "serving measurements done" serving_runner2.log 2>/dev/null; then break; fi
  sleep 20
done
for p in longctx ruler_frontier serve_batch lean_decode; do
  if pgrep -f "python $p.py" > /dev/null; then echo "[runner] GPU busy, refusing $(date -Is)"; exit 0; fi
done
echo "[runner] RULER dilation sweep start $(date -Is)"
python ruler_frontier.py \
  --ruler-jsonl /home/waas/ruler_a10_v1/ruler_subset.jsonl \
  --tasks niah_single_1 niah_multikey_2 niah_multikey_3 vt \
  --policies full obs_last \
  --budgets 512 1024 2048 \
  --obs 64 --nsink 4 --pool 7 --dilate 9 --max-new 32 --prefill-chunk 8192 \
  --out ruler_v2.json > ruler_v2.log 2>&1
echo "[runner] RULER dilation sweep done $(date -Is)"
