#!/usr/bin/env bash
# Expanded multi-record evaluation after the union confirmation run.
# 14 fresh records x {32K, 64K, 128K} x {full, obs_last, obs_union, obs_mean}.
set -u
cd /root/qcc/experiments/retention_frontier
source /root/qcc/venv/bin/activate
while pgrep -f "[l]ongctx.py" > /dev/null; do sleep 20; done
echo "[runner] starting expanded evaluation at $(date -Is)"
python longctx.py \
  --lengths 32768 65536 131072 \
  --policies full obs_last obs_union obs_mean \
  --budgets 128 256 512 \
  --seeds 110 111 112 113 114 115 116 117 118 119 120 121 122 123 \
  --pairs 2 --prefill-chunk 8192 --max-new 16 \
  --out expand_v1.json > expand_v1.log 2>&1
echo "[runner] expanded evaluation done at $(date -Is)"
