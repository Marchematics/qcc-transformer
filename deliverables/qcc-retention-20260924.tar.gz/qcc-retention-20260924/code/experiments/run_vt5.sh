#!/usr/bin/env bash
# vt: is it selection or simply "enough contiguous recent context"?
set -u
cd /root/qcc/experiments/retention_frontier
source /root/qcc/venv/bin/activate
echo "[vt5] start $(date -Is)"
python ruler_frontier.py \
  --ruler-jsonl /home/waas/ruler_a10_v1/ruler_subset.jsonl \
  --tasks vt --policies full recent lex_obs --budgets 4096 8192 16384 24576 \
  --obs 64 --nsink 4 --pool 7 --dilate 9 --lex-cap 512 --hops 6 \
  --key-chunk 4096 --max-new 128 --prefill-chunk 8192 \
  --out vt_probe5.json > vt_probe5.log 2>&1
echo "[vt5] done $(date -Is)"
