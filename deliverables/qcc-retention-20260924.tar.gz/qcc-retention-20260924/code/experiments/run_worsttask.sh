#!/bin/bash
# The binds: niah_multikey_3 is the worst task on every model.  Test whether more
# anchors or the union anchor set closes it, on the model where Full-KV is
# strongest (Qwen2.5-3B: Full-KV 0.80, bounded 0.733).
set -u
PY=/root/qcc/venv/bin/python
REPO=/root/qcc/repo/qcc-transformer
LOGS=/root/qcc/experiments/retention_frontier/multimodel
cd "$REPO" || exit 1
export PYTORCH_CUDA_ALLOC_CONF=expandable_segments:True
for script in run_campaign4.sh run_ablation2.sh run_pareto.sh run_stategrowth_long.sh \
              benchmark_retention_multimodel.py; do
  while pgrep -f "$script" > /dev/null; do sleep 60; done
done
run() {
  local name="$1"; shift
  local out="artifacts/$name.json"
  [ -f "$out" ] && { echo "=== $name exists"; return 0; }
  echo "=== $name start $(date +%H:%M:%S)"
  "$PY" benchmarks/benchmark_retention_multimodel.py --model /root/qcc/models/Qwen2.5-3B-Instruct \
    --max-prompt-tokens 32000 --tasks niah_multikey_3 --limit 20 "$@" --out "$out" \
    > "$LOGS/$name.log" 2>&1
  echo "=== $name exit=$? $(date +%H:%M:%S)"
}
run worst-multikey3-qwen3b-shipped
run worst-multikey3-qwen3b-both --anchor-mode both
run worst-multikey3-qwen3b-lex1024 --lex-cap 1024
echo "worsttask done $(date +%H:%M:%S)"
