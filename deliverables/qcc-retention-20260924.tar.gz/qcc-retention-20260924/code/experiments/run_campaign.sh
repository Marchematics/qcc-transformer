#!/bin/bash
# Campaign driver: runs GPU stages sequentially, one at a time.
#   main      : Llama-3.2-1B, 80 RULER records, packaged API, both arms (parity rerun)
#   nolex     : same, lexical anchors off at the same retained width
#   baselines : 7 selection policies at a matched 4096-slot budget, same 80 records
#   phi35     : Phi-3.5-mini (3.8B, MHA + LongRoPE, remote code), prompts <= 16K
#   qwen3b    : Qwen2.5-3B (36L, GQA 16/2), prompts <= 32K
#   llama8b   : Llama-3.1-8B (4-bit weights), all 80 records
#   longbench : LongBench (9 tasks x 20 records), Llama-3.2-1B, both arms
set -u
PY=/root/qcc/venv/bin/python
REPO=/root/qcc/repo/qcc-transformer
LOGS=/root/qcc/experiments/retention_frontier/multimodel
mkdir -p "$LOGS"
cd "$REPO" || exit 1
L1B=/root/qcc/models/Llama-3.2-1B-Instruct

run_stage() {
  local name="$1"; shift
  echo "=== $name start $(date +%H:%M:%S)"
  "$@" > "$LOGS/$name.log" 2>&1
  echo "=== $name exit=$? $(date +%H:%M:%S)"
}

for target in "$@"; do
  case "$target" in
    main)
      run_stage multimodel-llama1b "$PY" benchmarks/benchmark_retention_multimodel.py \
        --model "$L1B" --out artifacts/bounded-decode-frontier-multimodel-llama1b.json ;;
    nolex)
      run_stage multimodel-llama1b-nolex "$PY" benchmarks/benchmark_retention_multimodel.py \
        --model "$L1B" --budget 4608 --lex-cap 0 \
        --out artifacts/bounded-decode-frontier-multimodel-llama1b-nolex.json ;;
    nolex_mean)
      run_stage multimodel-llama1b-nolex-mean "$PY" benchmarks/benchmark_retention_multimodel.py \
        --model "$L1B" --budget 4608 --lex-cap 0 --scoring mean \
        --out artifacts/bounded-decode-frontier-multimodel-llama1b-nolex-mean.json ;;
    baselines)
      run_stage baselines-b4096 "$PY" benchmarks/benchmark_bounded_decode_ruler.py \
        --ruler-jsonl /home/waas/ruler_a10_v1/ruler_subset.jsonl \
        --tasks niah_single_1 niah_multikey_2 niah_multikey_3 vt \
        --policies full recent sink_recent obs_mean obs_max obs_last lex_obs \
        --budgets 4096 --obs 64 --nsink 4 --pool 7 --dilate 9 --lex-cap 512 --hops 6 \
        --key-chunk 4096 --max-new 128 --prefill-chunk 8192 \
        --out artifacts/bounded-decode-frontier-baselines-b4096.json ;;
    phi35)
      run_stage multimodel-phi35 "$PY" benchmarks/benchmark_retention_multimodel.py \
        --model /datasets/ComfyUI/models/LLM/Phi-3.5-mini-instruct \
        --trust-remote-code --attn-impl eager --prefill-chunk 1024 \
        --max-prompt-tokens 17000 \
        --out artifacts/bounded-decode-frontier-multimodel-phi35.json ;;
    qwen3b)
      run_stage multimodel-qwen2.5-3b "$PY" benchmarks/benchmark_retention_multimodel.py \
        --model /root/qcc/models/Qwen2.5-3B-Instruct --max-prompt-tokens 32000 \
        --out artifacts/bounded-decode-frontier-multimodel-qwen2.5-3b.json ;;
    llama8b)
      run_stage multimodel-llama3.1-8b "$PY" benchmarks/benchmark_retention_multimodel.py \
        --model /datasets/ComfyUI/models/LLM/Meta-Llama-3.1-8B-Instruct --load-4bit \
        --out artifacts/bounded-decode-frontier-multimodel-llama3.1-8b.json ;;
    longbench)
      run_stage longbench-llama1b "$PY" benchmarks/benchmark_retention_longbench.py \
        --model "$L1B" --tasks narrativeqa qasper hotpotqa 2wikimqa gov_report multi_news \
        triviaqa samsum passage_retrieval_en --limit 20 --budget 4096 --lex-cap 512 --hops 6 \
        --out artifacts/longbench-retention-llama32-1b.json ;;
    parity)
      run_stage parity-80 "$PY" benchmarks/compare_package_to_harness.py \
        --package artifacts/bounded-decode-frontier-multimodel-llama1b.json \
        --out artifacts/bounded-decode-frontier-parity-80.json ;;
    *)
      echo "unknown stage: $target" >&2; exit 2 ;;
  esac
done
echo "campaign done $(date +%H:%M:%S)"
