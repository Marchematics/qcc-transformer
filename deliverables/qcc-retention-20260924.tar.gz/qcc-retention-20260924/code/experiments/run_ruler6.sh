#!/usr/bin/env bash
# Full RULER suite with the official metric at budgets large enough for vt.
set -u
cd /root/qcc/experiments/retention_frontier
source /root/qcc/venv/bin/activate
echo "[r6] start $(date -Is)"
python ruler_frontier.py \
  --ruler-jsonl /home/waas/ruler_a10_v1/ruler_subset.jsonl \
  --tasks niah_single_1 niah_multikey_2 niah_multikey_3 vt \
  --policies full lex_obs --budgets 2048 4096 8192 \
  --obs 64 --nsink 4 --pool 7 --dilate 9 --lex-cap 512 --hops 6 \
  --key-chunk 4096 --max-new 128 --prefill-chunk 8192 \
  --out ruler_v6.json > ruler_v6.log 2>&1
echo "[r6] done $(date -Is)"
