#!/bin/bash
# Serialized, retrying queue for the remaining measurements.  One stage at a
# time, waits for free memory before each attempt, retries a failed attempt up to
# five times with a 20-minute backoff, and never reruns a stage whose artifact
# exists.
set -u
PY=/root/qcc/venv/bin/python
REPO=/root/qcc/repo/qcc-transformer
LOGS=/root/qcc/experiments/retention_frontier/multimodel
cd "$REPO" || exit 1
export PYTORCH_CUDA_ALLOC_CONF=expandable_segments:True
L1B=/root/qcc/models/Llama-3.2-1B-Instruct
QWEN=/root/qcc/models/Qwen2.5-3B-Instruct
NEED=7000

free_mib() { nvidia-smi --query-gpu=memory.free --format=csv,noheader,nounits | head -1; }

stage() {  # name command...
  local name="$1"; shift
  local out="artifacts/$name.json"
  for attempt in 1 2 3 4 5; do
    if [ -f "$out" ]; then echo "=== $name exists"; return 0; fi
    local waited=0
    while [ "$(free_mib)" -lt "$NEED" ]; do
      if [ "$waited" -ge 120 ]; then echo "=== $name giving up: $(free_mib) MiB free"; return 1; fi
      sleep 60; waited=$((waited + 1))
    done
    echo "=== $name attempt $attempt start $(date +%H:%M:%S) with $(free_mib) MiB free"
    "$@" > "$LOGS/$name.log" 2>&1
    local rc=$?
    echo "=== $name attempt $attempt exit=$rc $(date +%H:%M:%S)"
    [ "$rc" -eq 0 ] && return 0
    [ "$attempt" -lt 5 ] && sleep 1200
  done
  return 1
}

stage bounded-decode-frontier-multimodel-llama1b-nolex-mean \
  "$PY" benchmarks/benchmark_retention_multimodel.py --model "$L1B" \
  --budget 4608 --lex-cap 0 --scoring mean --key-chunk 1024 --prefill-chunk 4096 \
  --out artifacts/bounded-decode-frontier-multimodel-llama1b-nolex-mean.json

for variant in rare pattern; do
  stage "bounded-decode-frontier-multimodel-llama1b-$variant-hops0" \
    "$PY" benchmarks/benchmark_retention_multimodel.py --model "$L1B" \
    --anchor-mode "$variant" --hops 0 --key-chunk 1024 --prefill-chunk 4096 \
    --out "artifacts/bounded-decode-frontier-multimodel-llama1b-$variant-hops0.json"
done

for budget in 1024 2048; do
  stage "bounded-decode-frontier-multimodel-llama1b-b$budget" \
    "$PY" benchmarks/benchmark_retention_multimodel.py --model "$L1B" \
    --budget "$budget" --lex-cap 512 --hops 6 --key-chunk 1024 --prefill-chunk 4096 \
    --out "artifacts/bounded-decode-frontier-multimodel-llama1b-b$budget.json"
done

stage bounded-decode-frontier-state-growth-long \
  "$PY" benchmarks/benchmark_state_growth.py --lengths 131072 262144 524288 \
  --out artifacts/bounded-decode-frontier-state-growth-long.json

for variant in shipped both lex1024; do
  arg=(); [ "$variant" = both ] && arg=(--anchor-mode both)
  [ "$variant" = lex1024 ] && arg=(--lex-cap 1024)
  stage "worst-multikey3-qwen3b-$variant" \
    "$PY" benchmarks/benchmark_retention_multimodel.py --model "$QWEN" \
    --max-prompt-tokens 32000 --tasks niah_multikey_3 --limit 20 "${arg[@]}" \
    --key-chunk 1024 --prefill-chunk 4096 \
    --out "artifacts/worst-multikey3-qwen3b-$variant.json"
done
echo "final queue 2 done $(date +%H:%M:%S)"
