#!/usr/bin/env bash
# One pinned document, full LM quality/budget curve.
set -u
cd /root/qcc/experiments/retention_frontier
source /root/qcc/venv/bin/activate
DOC=lm_doc_32768.json
rm -f "$DOC"
for B in 1024 2048 4096 8192 16384; do
  echo "[lm5] B=$B start $(date -Is)"
  python lm_nll.py --length 32768 --suffix 256 --budget $B --policies obs_last \
    --document "$DOC" --save-document "$DOC" \
    --out lm_nll_pinned_b$B.json > lm_nll_pinned_b$B.log 2>&1
done
echo "[lm5] complete"
