#!/bin/bash
# Matched-budget eviction baselines over the same 80 RULER records.
# One prefill per record, then every policy decodes from its own selection at
# the same retained width, so the comparison is like-for-like in model, budget,
# prompt, decode loop and metric.
set -u
PY=/root/qcc/venv/bin/python
REPO=/root/qcc/repo/qcc-transformer
LOGS=/root/qcc/experiments/retention_frontier/multimodel
mkdir -p "$LOGS"
cd "$REPO" || exit 1

# wait for the cross-model driver(s) to finish before taking the GPU
while pgrep -f "run_multimodel.sh" > /dev/null; do sleep 60; done

echo "=== baselines start $(date +%H:%M:%S)"
"$PY" benchmarks/benchmark_bounded_decode_ruler.py \
  --ruler-jsonl /home/waas/ruler_a10_v1/ruler_subset.jsonl \
  --tasks niah_single_1 niah_multikey_2 niah_multikey_3 vt \
  --policies full recent sink_recent obs_mean obs_max obs_last lex_obs \
  --budgets 4096 --obs 64 --nsink 4 --pool 7 --dilate 9 --lex-cap 512 --hops 6 \
  --key-chunk 4096 --max-new 128 --prefill-chunk 8192 \
  --out artifacts/bounded-decode-frontier-baselines-b4096.json \
  > "$LOGS/baselines-b4096.log" 2>&1
echo "=== baselines exit=$? $(date +%H:%M:%S)"
