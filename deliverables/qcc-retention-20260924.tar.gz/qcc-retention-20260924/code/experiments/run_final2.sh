#!/usr/bin/env bash
# Remaining GPU work, strictly sequential:
#   1. official RULER with the lexical+attention hybrid (lex_obs)
#   2. CUDA-graph parity + re-timed TPOT floor
#   3. batched serving sweep (fixed topk_indices_batched)
set -u
cd /root/qcc/experiments/retention_frontier
source /root/qcc/venv/bin/activate

echo "[f2] RULER lex sweep start $(date -Is)"
python ruler_frontier.py \
  --ruler-jsonl /home/waas/ruler_a10_v1/ruler_subset.jsonl \
  --tasks niah_single_1 niah_multikey_2 niah_multikey_3 vt \
  --policies full obs_last lex_obs \
  --budgets 512 1024 2048 \
  --obs 64 --nsink 4 --pool 7 --dilate 9 --key-chunk 4096 \
  --max-new 32 --prefill-chunk 8192 \
  --out ruler_v3.json > ruler_v3.log 2>&1
echo "[f2] RULER lex sweep done $(date -Is)"

echo "[f2] parity start $(date -Is)"
python lean_decode.py --length 32768 --budget 1024 --modes dynamic static graph \
  --out lean_decode_32k_v2.json > lean_decode_32k_v2.log 2>&1
python lean_decode.py --length 131072 --budget 1024 --modes dynamic static graph \
  --out lean_decode_128k_v2.json > lean_decode_128k_v2.log 2>&1
echo "[f2] parity done $(date -Is)"

echo "[f2] serving start $(date -Is)"
python serve_batch.py --length 32768 --batches 1 2 4 8 16 32 \
  --policies full obs_last --budget 1024 --max-new 32 \
  --out serving_32k_v2.json > serving_32k_v2.log 2>&1
echo "[f2] serving done $(date -Is)"
echo "[f2] complete"
