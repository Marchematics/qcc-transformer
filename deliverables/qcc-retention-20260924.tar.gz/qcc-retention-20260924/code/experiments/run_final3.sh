#!/usr/bin/env bash
# Parity + re-timed TPOT floor with the slot/absolute-position fix, then the
# batched serving sweep.
set -u
cd /root/qcc/experiments/retention_frontier
source /root/qcc/venv/bin/activate
echo "[f3] parity 32K start $(date -Is)"
python lean_decode.py --length 32768 --budget 1024 --modes dynamic static graph \
  --out lean_decode_32k_v2.json > lean_decode_32k_v2.log 2>&1
echo "[f3] parity 128K start $(date -Is)"
python lean_decode.py --length 131072 --budget 1024 --modes dynamic static graph \
  --out lean_decode_128k_v2.json > lean_decode_128k_v2.log 2>&1
echo "[f3] parity done $(date -Is)"
echo "[f3] serving start $(date -Is)"
python serve_batch.py --length 32768 --batches 1 2 4 8 16 32 \
  --policies full obs_last --budget 1024 --max-new 32 \
  --out serving_32k_v2.json > serving_32k_v2.log 2>&1
echo "[f3] complete $(date -Is)"
