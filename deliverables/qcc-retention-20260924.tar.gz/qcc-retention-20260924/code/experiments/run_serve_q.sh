#!/usr/bin/env bash
# Serving metrics at the quality-guaranteeing retention budget (4096 + 512 anchors).
set -u
cd /root/qcc/experiments/retention_frontier
source /root/qcc/venv/bin/activate
echo "[sq] 32K start $(date -Is)"
python serve_sequential.py --length 32768 --batches 1 2 4 8 16 32 \
  --budget 4096 --lex-cap 512 --max-new 32 \
  --out serving_seq_32k_q4096.json > serving_seq_32k_q4096.log 2>&1
echo "[sq] 32K done $(date -Is)"
echo "[sq] 128K start $(date -Is)"
python serve_sequential.py --length 131072 --batches 1 2 4 8 \
  --budget 4096 --lex-cap 512 --max-new 32 \
  --out serving_seq_128k_q4096.json > serving_seq_128k_q4096.log 2>&1
echo "[sq] 128K done $(date -Is)"
