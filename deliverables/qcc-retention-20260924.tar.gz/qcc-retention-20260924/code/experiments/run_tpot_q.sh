#!/usr/bin/env bash
# Clean decode-only TPOT at the quality budget (4096 + 512 anchors).
set -u
cd /root/qcc/experiments/retention_frontier
for _ in $(seq 1 900); do
  grep -q "\[sq\] 128K done" sq_runner.log 2>/dev/null && break
  sleep 20
done
source /root/qcc/venv/bin/activate
echo "[tq] start $(date -Is)"
python lean_decode.py --length 32768 --budget 4096 --modes dynamic graph \
  --out tpot_q4096_32k.json > tpot_q4096_32k.log 2>&1
echo "[tq] done $(date -Is)"
