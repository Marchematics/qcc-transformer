#!/usr/bin/env bash
# Corrected parity check: static/graph must reproduce the dynamic tokens.
set -u
cd /root/qcc/experiments/retention_frontier
source /root/qcc/venv/bin/activate
for _ in $(seq 1 900); do
  if grep -q "\[f3\] complete" final3_runner.log 2>/dev/null; then break; fi
  sleep 20
done
for p in serve_batch lean_decode; do
  if pgrep -f "python $p.py" > /dev/null; then echo "[p2] busy, refusing $(date -Is)"; exit 0; fi
done
echo "[p2] start $(date -Is)"
python lean_decode.py --length 32768 --budget 1024 --modes dynamic static graph \
  --out lean_decode_32k_v3.json > lean_decode_32k_v3.log 2>&1
python lean_decode.py --length 131072 --budget 1024 --modes dynamic static graph \
  --out lean_decode_128k_v3.json > lean_decode_128k_v3.log 2>&1
echo "[p2] done $(date -Is)"
