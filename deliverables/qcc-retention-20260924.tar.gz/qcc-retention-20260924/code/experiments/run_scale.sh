#!/usr/bin/env bash
# After the serving measurements: does a larger retention budget close the
# remaining quality gap?  Same 60 records (seeds 101-106, 110-123) as
# aggregate_v2 + expand_v1, budgets 1024 and 2048.
set -u
cd /root/qcc/experiments/retention_frontier
source /root/qcc/venv/bin/activate
for _ in $(seq 1 900); do
  if grep -q "serving measurements done" serving_runner2.log 2>/dev/null; then break; fi
  sleep 20
done
if pgrep -f "[l]ongctx.py" > /dev/null || pgrep -f "[r]uler_frontier.py" > /dev/null \
   || pgrep -f "[s]erve_batch.py" > /dev/null || pgrep -f "[l]ean_decode.py" > /dev/null; then
  echo "[runner] GPU busy, refusing to start $(date -Is)"; exit 0
fi
echo "[runner] budget scaling start $(date -Is)"
python longctx.py --lengths 32768 65536 131072 \
  --policies full obs_last --budgets 1024 2048 \
  --seeds 101 102 103 104 105 106 110 111 112 113 114 115 116 117 118 119 120 121 122 123 \
  --pairs 2 --prefill-chunk 8192 --max-new 16 \
  --out scale_v1.json > scale_v1.log 2>&1
echo "[runner] budget scaling done $(date -Is)"
