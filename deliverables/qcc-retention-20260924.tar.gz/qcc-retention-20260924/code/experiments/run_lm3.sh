#!/usr/bin/env bash
# Language-modelling quality vs retention budget.
set -u
cd /root/qcc/experiments/retention_frontier
for _ in $(seq 1 900); do
  grep -q "\[lm2\] done" lm2_runner.log 2>/dev/null && break
  sleep 20
done
source /root/qcc/venv/bin/activate
for B in 2048 4096 8192; do
  echo "[lm3] budget=$B start $(date -Is)"
  python lm_nll.py --length 32768 --suffix 256 --budget $B \
    --policies obs_last --out lm_nll_32k_b$B.json > lm_nll_32k_b$B.log 2>&1
  echo "[lm3] budget=$B done $(date -Is)"
done
echo "[lm3] complete"
