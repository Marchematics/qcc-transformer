#!/bin/bash
# Third campaign: quality-vs-decode-state Pareto against KV quantization.
# Waits for the second campaign to finish so the GPU is never shared.
set -u
PY=/root/qcc/venv/bin/python
REPO=/root/qcc/repo/qcc-transformer
LOGS=/root/qcc/experiments/retention_frontier/multimodel
mkdir -p "$LOGS"
cd "$REPO" || exit 1
L1B=/root/qcc/models/Llama-3.2-1B-Instruct

while pgrep -f "run_campaign2.sh" > /dev/null; do sleep 60; done
echo "=== kvquant start $(date +%H:%M:%S)"
"$PY" benchmarks/benchmark_kv_quant_ruler.py \
  --model "$L1B" \
  --ruler-jsonl /home/waas/ruler_a10_v1/ruler_subset.jsonl \
  --tasks niah_single_1 niah_multikey_2 niah_multikey_3 vt \
  --limit 4 --budget 4096 --lex-cap 512 --group-size 128 --max-new 64 \
  --arms full full_int8 full_int4 bounded4096 bounded4096_int8 bounded4096_int4 \
  --out artifacts/bounded-decode-frontier-kv-quant.json \
  > "$LOGS/kvquant.log" 2>&1
echo "=== kvquant exit=$? $(date +%H:%M:%S)"
echo "campaign3 done $(date +%H:%M:%S)"
