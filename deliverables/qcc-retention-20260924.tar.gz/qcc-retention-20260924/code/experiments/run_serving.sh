#!/usr/bin/env bash
# After the RULER quality sweep: attack the decode-TPOT floor (with Full-KV given
# the same optimizations), then measure batched throughput / memory-limited
# concurrency.
set -u
cd /root/qcc/experiments/retention_frontier
source /root/qcc/venv/bin/activate
while pgrep -f "[r]uler_frontier.py" > /dev/null; do sleep 20; done
echo "[runner] RULER sweep finished, starting serving measurements $(date -Is)"

echo "[runner] lean decode 32K $(date -Is)"
python lean_decode.py --length 32768 --budget 1024 --modes dynamic static graph \
  --out lean_decode_32k.json > lean_decode_32k.log 2>&1

echo "[runner] lean decode 128K $(date -Is)"
python lean_decode.py --length 131072 --budget 1024 --modes dynamic static graph \
  --out lean_decode_128k.json > lean_decode_128k.log 2>&1

echo "[runner] batched serving 32K $(date -Is)"
python serve_batch.py --length 32768 --batches 1 2 4 8 16 \
  --policies full obs_last --budget 1024 --max-new 32 \
  --out serving_32k.json > serving_32k.log 2>&1

echo "[runner] serving measurements done $(date -Is)"
