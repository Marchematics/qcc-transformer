#!/usr/bin/env bash
set -u
cd /root/qcc/experiments/retention_frontier
source /root/qcc/venv/bin/activate
for B in 1024 4096; do
  echo "[tm] B=$B $(date -Is)"
  python lean_decode.py --length 131072 --budget $B --modes graph \
    --out tpot_min_b$B.json > tpot_min_b$B.log 2>&1
done
echo "[tm] done $(date -Is)"
