#!/usr/bin/env bash
# Cross-model quality: Phi-3.5-mini (3.8B) on the RULER 16K records.
set -u
cd /root/qcc/experiments/retention_frontier
source /root/qcc/venv/bin/activate
echo "[phi] start $(date -Is)"
python ruler_frontier.py \
  --model /datasets/ComfyUI/models/LLM/Phi-3.5-mini-instruct --trust-remote-code --prompt-template phi3 \
  --ruler-jsonl /home/waas/ruler_a10_v1/ruler_subset.jsonl \
  --tasks niah_single_1 niah_multikey_2 niah_multikey_3 vt \
  --min-length 7000 --max-length 9000 \
  --policies full lex_obs --budgets 1024 2048 \
  --obs 64 --nsink 4 --pool 7 --dilate 9 --lex-cap 512 --hops 6 \
  --key-chunk 4096 --max-new 32 --prefill-chunk 512 \
  --out phi_ruler_8k.json > phi_ruler_8k.log 2>&1
echo "[phi] done $(date -Is)"
