#!/bin/bash
# Cross-model generality runs. Each stage writes
# artifacts/bounded-decode-frontier-<stage>.json and logs to
# /root/qcc/experiments/retention_frontier/multimodel/<stage>.log
# Stages run sequentially: one GPU, one job at a time.
set -u
PY=/root/qcc/venv/bin/python
REPO=/root/qcc/repo/qcc-transformer
LOGS=/root/qcc/experiments/retention_frontier/multimodel
mkdir -p "$LOGS"
cd "$REPO" || exit 1

stage() {
  local name="$1"; shift
  echo "=== $name start $(date +%H:%M:%S)"
  "$PY" benchmarks/benchmark_retention_multimodel.py \
      --out "artifacts/bounded-decode-frontier-$name.json" "$@" \
      > "$LOGS/$name.log" 2>&1
  echo "=== $name exit=$? $(date +%H:%M:%S)"
}

for target in "$@"; do
  case "$target" in
    llama1b)
      stage multimodel-llama1b --model /root/qcc/models/Llama-3.2-1B-Instruct ;;
    llama1b_nolex)
      stage multimodel-llama1b-nolex --model /root/qcc/models/Llama-3.2-1B-Instruct \
        --budget 4608 --lex-cap 0 ;;
    phi35)
      stage multimodel-phi35 \
        --model /datasets/ComfyUI/models/LLM/Phi-3.5-mini-instruct \
        --trust-remote-code --attn-impl eager --prefill-chunk 1024 \
        --max-prompt-tokens 17000 ;;
    phi35_nolex)
      stage multimodel-phi35-nolex \
        --model /datasets/ComfyUI/models/LLM/Phi-3.5-mini-instruct \
        --trust-remote-code --attn-impl eager --prefill-chunk 1024 \
        --max-prompt-tokens 17000 --budget 4608 --lex-cap 0 ;;
    qwen3b)
      # Qwen2.5 has a 32K native window; longer prompts are skipped, not truncated
      stage multimodel-qwen2.5-3b --model /root/qcc/models/Qwen2.5-3B-Instruct \
        --max-prompt-tokens 32000 ;;
    qwen3b_nolex)
      stage multimodel-qwen2.5-3b-nolex --model /root/qcc/models/Qwen2.5-3B-Instruct \
        --max-prompt-tokens 32000 --budget 4608 --lex-cap 0 ;;
    llama8b)
      stage multimodel-llama3.1-8b --model /datasets/ComfyUI/models/LLM/Meta-Llama-3.1-8B-Instruct \
        --load-4bit ;;
    llama8b_nolex)
      stage multimodel-llama3.1-8b-nolex \
        --model /datasets/ComfyUI/models/LLM/Meta-Llama-3.1-8B-Instruct \
        --load-4bit --budget 4608 --lex-cap 0 ;;
    *)
      echo "unknown stage: $target" >&2; exit 2 ;;
  esac
done
echo "all stages done $(date +%H:%M:%S)"
