#!/usr/bin/env bash
# vt: does keeping the document header (larger attention sink) let the model
# sustain the multi-item list from a bounded cache?
set -u
cd /root/qcc/experiments/retention_frontier
for _ in $(seq 1 300); do
  grep -q "\[vt\] done" vt_runner.log 2>/dev/null && break
  sleep 20
done
source /root/qcc/venv/bin/activate
echo "[vt2] start $(date -Is)"
python ruler_frontier.py \
  --ruler-jsonl /home/waas/ruler_a10_v1/ruler_subset.jsonl \
  --tasks vt --policies full lex_obs --budgets 1024 2048 \
  --obs 64 --nsink 96 --pool 7 --dilate 9 --lex-cap 512 --hops 6 \
  --key-chunk 4096 --max-new 48 --prefill-chunk 8192 \
  --out vt_probe2.json > vt_probe2.log 2>&1
echo "[vt2] done $(date -Is)"
