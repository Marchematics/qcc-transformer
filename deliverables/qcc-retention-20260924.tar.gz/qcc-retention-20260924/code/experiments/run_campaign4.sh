#!/bin/bash
# Retry-capable campaign: the card is shared, so every stage waits for free
# memory, skips stages whose artifact already exists, and continues past a
# failure instead of losing the whole queue.
set -u
PY=/root/qcc/venv/bin/python
REPO=/root/qcc/repo/qcc-transformer
LOGS=/root/qcc/experiments/retention_frontier/multimodel
cd "$REPO" || exit 1
L1B=/root/qcc/models/Llama-3.2-1B-Instruct
export PYTORCH_CUDA_ALLOC_CONF=expandable_segments:True

while pgrep -f "run_campaign.sh" > /dev/null; do sleep 60; done
while pgrep -f "run_campaign2.sh" > /dev/null; do sleep 60; done
while pgrep -f "run_campaign3.sh" > /dev/null; do sleep 60; done

free_gib() {
  nvidia-smi --query-gpu=memory.free --format=csv,noheader,nounits | head -1 | awk '{print int($1/1024)}'
}

wait_free() {  # $1 = GiB needed, $2 = minutes to wait
  local need=$1 minutes=${2:-180} i
  for ((i = 0; i < minutes; i++)); do
    if [ "$(free_gib)" -ge "$need" ]; then return 0; fi
    sleep 60
  done
  return 1
}

run_stage() {  # name out need_gib command...
  local name="$1" out="$2" need="$3"; shift 3
  if [ -f "$out" ]; then echo "=== $name skipped, artifact exists $(date +%H:%M:%S)"; return 0; fi
  if ! wait_free "$need"; then
    echo "=== $name skipped, only $(free_gib) GiB free $(date +%H:%M:%S)"; return 1
  fi
  echo "=== $name start $(date +%H:%M:%S) with $(free_gib) GiB free"
  "$@" > "$LOGS/$name.log" 2>&1
  echo "=== $name exit=$? $(date +%H:%M:%S)"
}

baselines() {
  run_stage baselines-b4096 artifacts/bounded-decode-frontier-baselines-b4096.json 6 \
    "$PY" benchmarks/benchmark_bounded_decode_ruler.py \
      --ruler-jsonl /home/waas/ruler_a10_v1/ruler_subset.jsonl \
      --tasks niah_single_1 niah_multikey_2 niah_multikey_3 vt \
      --policies full recent sink_recent obs_mean obs_max obs_last lex_obs \
      --budgets 4096 --obs 64 --nsink 4 --pool 7 --dilate 9 --lex-cap 512 --hops 6 \
      --key-chunk 1024 --max-new 128 --prefill-chunk 8192 \
      --out artifacts/bounded-decode-frontier-baselines-b4096.json
}

case "${1:-all}" in
  baselines) baselines ;;
  cross)
    run_stage multimodel-qwen2.5-3b artifacts/bounded-decode-frontier-multimodel-qwen2.5-3b.json 6 \
      "$PY" benchmarks/benchmark_retention_multimodel.py \
        --model /root/qcc/models/Qwen2.5-3B-Instruct --max-prompt-tokens 32000 \
        --out artifacts/bounded-decode-frontier-multimodel-qwen2.5-3b.json
    run_stage multimodel-phi35 artifacts/bounded-decode-frontier-multimodel-phi35.json 14 \
      "$PY" benchmarks/benchmark_retention_multimodel.py \
        --model /datasets/ComfyUI/models/LLM/Phi-3.5-mini-instruct \
        --trust-remote-code --attn-impl eager --prefill-chunk 512 \
        --max-prompt-tokens 17000 \
        --out artifacts/bounded-decode-frontier-multimodel-phi35.json
    run_stage multimodel-llama3.1-8b artifacts/bounded-decode-frontier-multimodel-llama3.1-8b.json 8 \
      "$PY" benchmarks/benchmark_retention_multimodel.py \
        --model /datasets/ComfyUI/models/LLM/Meta-Llama-3.1-8B-Instruct --load-4bit \
        --prefill-chunk 4096 \
        --out artifacts/bounded-decode-frontier-multimodel-llama3.1-8b.json
    ;;
  ablation)
    run_stage multimodel-llama1b-nolex-mean artifacts/bounded-decode-frontier-multimodel-llama1b-nolex-mean.json 6 \
      "$PY" benchmarks/benchmark_retention_multimodel.py \
        --model "$L1B" --budget 4608 --lex-cap 0 --scoring mean \
        --out artifacts/bounded-decode-frontier-multimodel-llama1b-nolex-mean.json
    run_stage multimodel-llama1b-nolex artifacts/bounded-decode-frontier-multimodel-llama1b-nolex.json 6 \
      "$PY" benchmarks/benchmark_retention_multimodel.py \
        --model "$L1B" --budget 4608 --lex-cap 0 \
        --out artifacts/bounded-decode-frontier-multimodel-llama1b-nolex.json
    run_stage multimodel-llama1b-rare artifacts/bounded-decode-frontier-multimodel-llama1b-rare.json 6 \
      "$PY" benchmarks/benchmark_retention_multimodel.py \
        --model "$L1B" --anchor-mode rare \
        --out artifacts/bounded-decode-frontier-multimodel-llama1b-rare.json
    ;;
  longbench)
    run_stage longbench-llama1b artifacts/longbench-retention-llama32-1b.json 6 \
      "$PY" benchmarks/benchmark_retention_longbench.py \
        --model "$L1B" --tasks narrativeqa qasper hotpotqa 2wikimqa gov_report multi_news \
        triviaqa samsum passage_retrieval_en --limit 20 --budget 4096 --lex-cap 512 --hops 6 \
        --out artifacts/longbench-retention-llama32-1b.json
    ;;
  stategrowth)
    run_stage state-growth artifacts/bounded-decode-frontier-state-growth.json 10 \
      "$PY" benchmarks/benchmark_state_growth.py \
        --lengths 8192 32768 65536 131072 262144 524288 \
        --out artifacts/bounded-decode-frontier-state-growth.json
    ;;
  lexonly)
    run_stage baselines-lexonly artifacts/bounded-decode-frontier-lexonly-b4096.json 6 \
      "$PY" benchmarks/benchmark_bounded_decode_ruler.py \
        --ruler-jsonl /home/waas/ruler_a10_v1/ruler_subset.jsonl \
        --tasks niah_single_1 niah_multikey_2 niah_multikey_3 vt \
        --policies full lex_only lex_obs obs_last --budgets 4096 \
        --obs 64 --nsink 4 --pool 7 --dilate 9 --lex-cap 512 --hops 6 \
        --key-chunk 1024 --max-new 128 --prefill-chunk 8192 \
        --out artifacts/bounded-decode-frontier-lexonly-b4096.json
    ;;
  all)
    baselines
    "$0" cross
    "$0" ablation
    "$0" longbench
    "$0" stategrowth
    "$0" lexonly
    ;;
esac
echo "campaign4 ($1) done $(date +%H:%M:%S)"
