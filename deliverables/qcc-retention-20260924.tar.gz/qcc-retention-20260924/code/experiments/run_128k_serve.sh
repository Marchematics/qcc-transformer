#!/usr/bin/env bash
# 128K serving: sequential prefill + resident bounded caches + batched decode.
set -u
cd /root/qcc/experiments/retention_frontier
source /root/qcc/venv/bin/activate
echo "[s128] start $(date -Is)"
python serve_sequential.py --length 131072 --batches 1 2 4 8 \
  --budget 1024 --lex-cap 128 --max-new 32 \
  --out serving_seq_128k.json > serving_seq_128k.log 2>&1
echo "[s128] done $(date -Is)"
