#!/bin/bash
# Attribution follow-ups: rarity without chain-following, and pattern anchors
# without chain-following, at the shipped retained width.
set -u
PY=/root/qcc/venv/bin/python
REPO=/root/qcc/repo/qcc-transformer
LOGS=/root/qcc/experiments/retention_frontier/multimodel
cd "$REPO" || exit 1
export PYTORCH_CUDA_ALLOC_CONF=expandable_segments:True
while pgrep -f "run_campaign4.sh" > /dev/null; do sleep 60; done
for variant in rare pattern; do
  out="artifacts/bounded-decode-frontier-multimodel-llama1b-$variant-hops0.json"
  [ -f "$out" ] && { echo "=== $variant-hops0 exists"; continue; }
  free=$(nvidia-smi --query-gpu=memory.free --format=csv,noheader,nounits | head -1)
  [ "$free" -lt 6144 ] && { echo "=== $variant-hops0 skipped, $free MiB free"; continue; }
  echo "=== $variant-hops0 start $(date +%H:%M:%S)"
  "$PY" benchmarks/benchmark_retention_multimodel.py --model /root/qcc/models/Llama-3.2-1B-Instruct \
    --anchor-mode "$variant" --hops 0 --out "$out" > "$LOGS/multimodel-llama1b-$variant-hops0.log" 2>&1
  echo "=== $variant-hops0 exit=$? $(date +%H:%M:%S)"
done
echo "ablation2 done $(date +%H:%M:%S)"
