#!/usr/bin/env bash
# Parity + TPOT after fixing the dynamic reference cache.
set -u
cd /root/qcc/experiments/retention_frontier
source /root/qcc/venv/bin/activate
echo "[tpot] 32K start $(date -Is)"
python lean_decode.py --length 32768 --budget 1024 --modes dynamic static graph \
  --out lean_decode_32k_v4.json > lean_decode_32k_v4.log 2>&1
echo "[tpot] 128K start $(date -Is)"
python lean_decode.py --length 131072 --budget 1024 --modes dynamic static graph \
  --out lean_decode_128k_v4.json > lean_decode_128k_v4.log 2>&1
echo "[tpot] done $(date -Is)"
