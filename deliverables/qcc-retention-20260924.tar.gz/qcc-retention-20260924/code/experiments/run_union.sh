#!/usr/bin/env bash
# After the 1M feasibility point finishes, run the Borda rank-fusion policy
# (obs_last + obs_mean) on the same 18 records as aggregate_v2.
set -u
cd /root/qcc/experiments/retention_frontier
source /root/qcc/venv/bin/activate
while pgrep -f "[l]ongctx.py" > /dev/null; do sleep 20; done
echo "[runner] 1M point finished, starting union confirmation at $(date -Is)"
python longctx.py \
  --lengths 32768 65536 131072 \
  --policies obs_union \
  --budgets 128 256 512 \
  --seeds 101 102 103 104 105 106 \
  --pairs 2 --prefill-chunk 8192 --max-new 16 \
  --out union_v1.json > union_v1.log 2>&1
echo "[runner] union confirmation done at $(date -Is)"
