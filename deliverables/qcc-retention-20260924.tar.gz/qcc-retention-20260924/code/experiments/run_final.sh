#!/usr/bin/env bash
# Union confirmation, then the expanded multi-record evaluation.
set -u
cd /root/qcc/experiments/retention_frontier
source /root/qcc/venv/bin/activate

echo "[runner] union confirmation start $(date -Is)"
python longctx.py \
  --lengths 32768 65536 131072 \
  --policies obs_union \
  --budgets 128 256 512 \
  --seeds 101 102 103 104 105 106 \
  --pairs 2 --prefill-chunk 8192 --max-new 16 \
  --out union_v1.json > union_v1.log 2>&1
echo "[runner] union confirmation done $(date -Is)"

echo "[runner] expanded evaluation start $(date -Is)"
python longctx.py \
  --lengths 32768 65536 131072 \
  --policies full obs_last obs_union obs_mean \
  --budgets 128 256 512 \
  --seeds 110 111 112 113 114 115 116 117 118 119 120 121 122 123 \
  --pairs 2 --prefill-chunk 8192 --max-new 16 \
  --out expand_v1.json > expand_v1.log 2>&1
echo "[runner] expanded evaluation done $(date -Is)"
