#!/usr/bin/env bash
# Round 6: official RULER with assignment-chain following for variable tracking.
set -u
cd /root/qcc/experiments/retention_frontier
source /root/qcc/venv/bin/activate
echo "[c6] RULER chain sweep start $(date -Is)"
python ruler_frontier.py \
  --ruler-jsonl /home/waas/ruler_a10_v1/ruler_subset.jsonl \
  --tasks niah_single_1 niah_multikey_2 niah_multikey_3 vt \
  --policies full obs_last lex_obs --budgets 512 1024 2048 \
  --obs 64 --nsink 4 --pool 7 --dilate 9 --lex-cap 128 --hops 6 \
  --key-chunk 4096 --max-new 32 --prefill-chunk 8192 \
  --out ruler_v5.json > ruler_v5.log 2>&1
echo "[c6] RULER done $(date -Is)"
