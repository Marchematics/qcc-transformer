#!/usr/bin/env bash
# Batched serving sweep, corrected per-row score stacking.
set -u
cd /root/qcc/experiments/retention_frontier
source /root/qcc/venv/bin/activate
if pgrep -f "[s]erve_batch.py" > /dev/null || pgrep -f "[l]ean_decode.py" > /dev/null; then
  echo "[serve3] GPU busy, refusing $(date -Is)"; exit 0; fi
echo "[serve3] start $(date -Is)"
python serve_batch.py --length 32768 --batches 1 2 4 8 16 32 \
  --policies full obs_last --budget 1024 --max-new 32 \
  --out serving_32k_v2.json > serving_32k_v2.log 2>&1
echo "[serve3] done $(date -Is)"
