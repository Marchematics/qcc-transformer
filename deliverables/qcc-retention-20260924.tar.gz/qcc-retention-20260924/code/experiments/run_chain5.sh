#!/usr/bin/env bash
# Round 5: corrected RULER sweep, then the sequential-prefill concurrency sweep.
set -u
cd /root/qcc/experiments/retention_frontier
source /root/qcc/venv/bin/activate

echo "[c5] RULER corrected lex sweep start $(date -Is)"
python ruler_frontier.py \
  --ruler-jsonl /home/waas/ruler_a10_v1/ruler_subset.jsonl \
  --tasks niah_single_1 niah_multikey_2 niah_multikey_3 vt \
  --policies full obs_last lex_obs \
  --budgets 512 1024 2048 --obs 64 --nsink 4 --pool 7 --dilate 9 \
  --lex-cap 128 --key-chunk 4096 --max-new 32 --prefill-chunk 8192 \
  --out ruler_v4.json > ruler_v4.log 2>&1
echo "[c5] RULER done $(date -Is)"

echo "[c5] sequential concurrency sweep start $(date -Is)"
python serve_sequential.py --length 32768 --batches 1 2 4 8 16 32 \
  --budget 1024 --lex-cap 128 --max-new 32 \
  --out serving_seq_32k.json > serving_seq_32k.log 2>&1
echo "[c5] sequential done $(date -Is)"
echo "[c5] complete"
