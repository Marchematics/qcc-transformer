#!/usr/bin/env bash
# Complete the LM quality/budget curve at a 50% budget.
set -u
cd /root/qcc/experiments/retention_frontier
for _ in $(seq 1 900); do
  grep -q "\[vt4\] done" vt4_runner.log 2>/dev/null && break
  sleep 20
done
source /root/qcc/venv/bin/activate
echo "[lm4] start $(date -Is)"
python lm_nll.py --length 32768 --suffix 256 --budget 16384 \
  --policies obs_last --out lm_nll_32k_b16384.json > lm_nll_32k_b16384.log 2>&1
echo "[lm4] done $(date -Is)"
