#!/bin/bash
# One long-lived queue for everything still missing, resilient to the shared
# card: each stage waits (up to 8 h) for the memory it needs, skips stages whose
# artifact already exists, and continues past failures.
set -u
PY=/root/qcc/venv/bin/python
REPO=/root/qcc/repo/qcc-transformer
LOGS=/root/qcc/experiments/retention_frontier/multimodel
cd "$REPO" || exit 1
export PYTORCH_CUDA_ALLOC_CONF=expandable_segments:True
L1B=/root/qcc/models/Llama-3.2-1B-Instruct
QWEN=/root/qcc/models/Qwen2.5-3B-Instruct

free_mib() { nvidia-smi --query-gpu=memory.free --format=csv,noheader,nounits | head -1; }

stage() {  # name need_mib command...
  local name="$1" need="$2"; shift 2
  local out="$LOGS/../.."; out="$REPO/artifacts/$name.json"
  if [ -f "$out" ]; then echo "=== $name exists"; return 0; fi
  local waited=0
  while [ "$(free_mib)" -lt "$need" ]; do
    [ "$waited" -ge 480 ] && { echo "=== $name skipped, only $(free_mib) MiB free"; return 1; }
    sleep 60; waited=$((waited + 1))
  done
  echo "=== $name start $(date +%H:%M:%S) with $(free_mib) MiB free"
  "$@" > "$LOGS/$name.log" 2>&1
  echo "=== $name exit=$? $(date +%H:%M:%S)"
}

stage multimodel-llama1b-nolex-mean 6144 \
  "$PY" benchmarks/benchmark_retention_multimodel.py --model "$L1B" \
  --budget 4608 --lex-cap 0 --scoring mean \
  --out artifacts/multimodel-llama1b-nolex-mean.json
# the runner above writes to the path given in --out; keep the artifact name stable
[ -f artifacts/multimodel-llama1b-nolex-mean.json ] && \
  mv -f artifacts/multimodel-llama1b-nolex-mean.json \
        artifacts/bounded-decode-frontier-multimodel-llama1b-nolex-mean.json

for variant in rare pattern; do
  stage "multimodel-llama1b-$variant-hops0" 6144 \
    "$PY" benchmarks/benchmark_retention_multimodel.py --model "$L1B" \
    --anchor-mode "$variant" --hops 0 \
    --out "artifacts/bounded-decode-frontier-multimodel-llama1b-$variant-hops0.json"
done

for budget in 1024 2048; do
  stage "multimodel-llama1b-b$budget" 6144 \
    "$PY" benchmarks/benchmark_retention_multimodel.py --model "$L1B" \
    --budget "$budget" --lex-cap 512 --hops 6 \
    --out "artifacts/bounded-decode-frontier-multimodel-llama1b-b$budget.json"
done

stage state-growth-long 10240 \
  "$PY" benchmarks/benchmark_state_growth.py --lengths 131072 262144 524288 \
  --out artifacts/bounded-decode-frontier-state-growth-long.json

for variant in shipped both lex1024; do
  arg=(); [ "$variant" = both ] && arg=(--anchor-mode both)
  [ "$variant" = lex1024 ] && arg=(--lex-cap 1024)
  stage "worst-multikey3-qwen3b-$variant" 8192 \
    "$PY" benchmarks/benchmark_retention_multimodel.py --model "$QWEN" \
    --max-prompt-tokens 32000 --tasks niah_multikey_3 --limit 20 "${arg[@]}" \
    --out "artifacts/worst-multikey3-qwen3b-$variant.json"
done
echo "final queue done $(date +%H:%M:%S)"
