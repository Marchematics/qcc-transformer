#!/usr/bin/env bash
# Batched serving sweep re-run after the topk_indices_batched reshape fix.
set -u
cd /root/qcc/experiments/retention_frontier
source /root/qcc/venv/bin/activate
for _ in $(seq 1 900); do
  if grep -q "\[parity\] done" parity_runner.log 2>/dev/null; then break; fi
  sleep 20
done
for p in longctx ruler_frontier serve_batch lean_decode; do
  if pgrep -f "python $p.py" > /dev/null; then echo "[serve2] GPU busy, refusing $(date -Is)"; exit 0; fi
done
echo "[serve2] batched serving start $(date -Is)"
python serve_batch.py --length 32768 --batches 1 2 4 8 16 32 \
  --policies full obs_last --budget 1024 --max-new 32 \
  --out serving_32k_v2.json > serving_32k_v2.log 2>&1
echo "[serve2] done $(date -Is)"
