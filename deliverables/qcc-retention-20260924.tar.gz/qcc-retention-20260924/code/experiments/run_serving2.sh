#!/usr/bin/env bash
# Wait for the RULER sweep to actually finish (sentinel line in its runner log),
# then run the TPOT-floor and batched-serving measurements.
set -u
cd /root/qcc/experiments/retention_frontier
source /root/qcc/venv/bin/activate
for _ in $(seq 1 600); do
  if grep -q "RULER frontier done" ruler_runner.log 2>/dev/null; then break; fi
  sleep 20
done
if ! pgrep -f "[l]ongctx.py" > /dev/null && ! pgrep -f "[r]uler_frontier.py" > /dev/null; then
  echo "[runner] starting serving measurements $(date -Is)"
  python lean_decode.py --length 32768 --budget 1024 --modes dynamic static graph \
    --out lean_decode_32k.json > lean_decode_32k.log 2>&1
  echo "[runner] lean 32K done $(date -Is)"
  python lean_decode.py --length 131072 --budget 1024 --modes dynamic static graph \
    --out lean_decode_128k.json > lean_decode_128k.log 2>&1
  echo "[runner] lean 128K done $(date -Is)"
  python serve_batch.py --length 32768 --batches 1 2 4 8 16 \
    --policies full obs_last --budget 1024 --max-new 32 \
    --out serving_32k.json > serving_32k.log 2>&1
  echo "[runner] serving measurements done $(date -Is)"
else
  echo "[runner] GPU still busy, refusing to start $(date -Is)"
fi
