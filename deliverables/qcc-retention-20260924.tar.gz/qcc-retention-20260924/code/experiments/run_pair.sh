#!/usr/bin/env bash
# Both arms in one process, one window: matched Full-KV dynamic vs bounded graph.
set -u
cd /root/qcc/experiments/retention_frontier
source /root/qcc/venv/bin/activate
for B in 1024 4096; do
  echo "[pair] B=$B $(date -Is)"
  python lean_decode.py --length 131072 --budget $B --modes dynamic graph \
    --out pair_b$B.json > pair_b$B.log 2>&1
done
echo "[pair] done $(date -Is)"
