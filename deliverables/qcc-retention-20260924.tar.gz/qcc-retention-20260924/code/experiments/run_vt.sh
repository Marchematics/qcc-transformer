#!/usr/bin/env bash
# vt diagnosis: is the residual vt gap capacity, cleanliness, or generation?
set -u
cd /root/qcc/experiments/retention_frontier
source /root/qcc/venv/bin/activate
echo "[vt] start $(date -Is)"
python ruler_frontier.py \
  --ruler-jsonl /home/waas/ruler_a10_v1/ruler_subset.jsonl \
  --tasks vt --policies full lex_obs lex_only --budgets 2048 4096 8192 \
  --obs 64 --nsink 4 --pool 7 --dilate 9 --lex-cap 1024 --hops 6 \
  --key-chunk 4096 --max-new 48 --prefill-chunk 8192 \
  --out vt_probe.json > vt_probe.log 2>&1
echo "[vt] done $(date -Is)"
