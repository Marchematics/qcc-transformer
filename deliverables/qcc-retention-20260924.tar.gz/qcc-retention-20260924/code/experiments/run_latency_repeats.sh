#!/bin/bash
# TPOT repeats on a (currently) idle card, for percentiles rather than a single
# number.  Five repeats per length, three execution paths for each of the two
# cache arms, same prompt construction as the earlier single-shot runs.
set -u
PY=/root/qcc/venv/bin/python
REPO=/root/qcc/repo/qcc-transformer
LOGS=/root/qcc/experiments/retention_frontier/multimodel
OUT=/root/qcc/experiments/retention_frontier/latency
mkdir -p "$OUT"
cd "$REPO" || exit 1
export PYTORCH_CUDA_ALLOC_CONF=expandable_segments:True
for length in 32768 131072; do
  for repeat in 1 2 3 4 5; do
    json="$OUT/tpot-floor-${length}-r${repeat}.json"
    [ -f "$json" ] && { echo "=== skip $json"; continue; }
    free=$(nvidia-smi --query-gpu=memory.free --format=csv,noheader,nounits | head -1)
    echo "=== length=$length repeat=$repeat free=${free}MiB $(date +%H:%M:%S)"
    "$PY" benchmarks/benchmark_bounded_decode_tpot_floor.py \
      --length "$length" --budget 4096 --max-new 32 \
      --modes dynamic static graph --seed $((9000 + repeat)) \
      --out "$json" > "$LOGS/tpot-floor-${length}-r${repeat}.log" 2>&1
    echo "=== exit=$? $(date +%H:%M:%S)"
  done
done
echo "latency repeats done $(date +%H:%M:%S)"
