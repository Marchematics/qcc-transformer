#!/bin/bash
# Closing the cross-family worst task: does window-mean scoring plus the anchors
# beat last-query scoring plus the anchors, where the gap actually is?
set -u
PY=/root/qcc/venv/bin/python
REPO=/root/qcc/repo/qcc-transformer
LOGS=/root/qcc/experiments/retention_frontier/multimodel
cd "$REPO" || exit 1
export PYTORCH_CUDA_ALLOC_CONF=expandable_segments:True
L1B=/root/qcc/models/Llama-3.2-1B-Instruct
QWEN=/root/qcc/models/Qwen2.5-3B-Instruct

free_mib() { nvidia-smi --query-gpu=memory.free --format=csv,noheader,nounits | head -1; }

run() {  # name need_mib command...
  local name="$1" need="$2"; shift 2
  local out="artifacts/$name.json"
  [ -f "$out" ] && { echo "=== $name exists"; return 0; }
  local waited=0
  while [ "$(free_mib)" -lt "$need" ]; do
    if [ "$waited" -ge 90 ]; then echo "=== $name giving up, $(free_mib) MiB free"; return 1; fi
    sleep 60; waited=$((waited + 1))
  done
  echo "=== $name start $(date +%H:%M:%S) free=$(free_mib)MiB"
  "$@" > "$LOGS/$name.log" 2>&1
  echo "=== $name exit=$? $(date +%H:%M:%S)"
}

run bounded-decode-frontier-multimodel-llama1b-mean-anchors 7000 \
  "$PY" benchmarks/benchmark_retention_multimodel.py --model "$L1B" \
  --scoring mean --key-chunk 1024 --prefill-chunk 4096 \
  --out artifacts/bounded-decode-frontier-multimodel-llama1b-mean-anchors.json

run worst-multikey3-qwen3b-mean-anchors 8192 \
  "$PY" benchmarks/benchmark_retention_multimodel.py --model "$QWEN" \
  --max-prompt-tokens 32000 --tasks niah_multikey_3 --limit 20 --scoring mean \
  --key-chunk 1024 --prefill-chunk 4096 \
  --out artifacts/worst-multikey3-qwen3b-mean-anchors.json

run worst-multikey3-phi35-mean-anchors 16384 \
  "$PY" benchmarks/benchmark_retention_multimodel.py \
  --model /datasets/ComfyUI/models/LLM/Phi-3.5-mini-instruct \
  --trust-remote-code --attn-impl eager --prefill-chunk 512 \
  --max-prompt-tokens 17000 --tasks niah_multikey_3 --limit 20 --scoring mean \
  --key-chunk 1024 \
  --out artifacts/worst-multikey3-phi35-mean-anchors.json
echo "round22 done $(date +%H:%M:%S)"
