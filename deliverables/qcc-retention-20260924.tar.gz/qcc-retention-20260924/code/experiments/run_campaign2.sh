#!/bin/bash
# Second campaign: runs after run_campaign.sh has fully exited.
#   rare       : Llama-3.2-1B with the task-agnostic rare-string anchor mode
#   lexonly    : anchors only (no attention ranking), for attribution
#   stategrowth: retained slots / state bytes vs prompt length, up to 512K
set -u
PY=/root/qcc/venv/bin/python
REPO=/root/qcc/repo/qcc-transformer
LOGS=/root/qcc/experiments/retention_frontier/multimodel
mkdir -p "$LOGS"
cd "$REPO" || exit 1
L1B=/root/qcc/models/Llama-3.2-1B-Instruct

while pgrep -f "run_campaign.sh" > /dev/null; do sleep 60; done

run_stage() {
  local name="$1"; shift
  echo "=== $name start $(date +%H:%M:%S)"
  "$@" > "$LOGS/$name.log" 2>&1
  echo "=== $name exit=$? $(date +%H:%M:%S)"
}

for target in "$@"; do
  case "$target" in
    rare)
      run_stage multimodel-llama1b-rare "$PY" benchmarks/benchmark_retention_multimodel.py \
        --model "$L1B" --anchor-mode rare \
        --out artifacts/bounded-decode-frontier-multimodel-llama1b-rare.json ;;
    rare_nolex)
      run_stage multimodel-llama1b-rare-both "$PY" benchmarks/benchmark_retention_multimodel.py \
        --model "$L1B" --anchor-mode both --budget 4608 --lex-cap 0 \
        --out artifacts/bounded-decode-frontier-multimodel-llama1b-rare-both.json ;;
    lexonly)
      run_stage baselines-lexonly "$PY" benchmarks/benchmark_bounded_decode_ruler.py \
        --ruler-jsonl /home/waas/ruler_a10_v1/ruler_subset.jsonl \
        --tasks niah_single_1 niah_multikey_2 niah_multikey_3 vt \
        --policies full lex_only lex_obs obs_last --budgets 4096 \
        --obs 64 --nsink 4 --pool 7 --dilate 9 --lex-cap 512 --hops 6 \
        --key-chunk 4096 --max-new 128 --prefill-chunk 8192 \
        --out artifacts/bounded-decode-frontier-lexonly-b4096.json ;;
    stategrowth)
      run_stage state-growth "$PY" benchmarks/benchmark_state_growth.py \
        --lengths 8192 32768 65536 131072 262144 524288 \
        --out artifacts/bounded-decode-frontier-state-growth.json ;;
    *)
      echo "unknown stage: $target" >&2; exit 2 ;;
  esac
done
echo "campaign2 done $(date +%H:%M:%S)"
