#!/usr/bin/env bash
set -u
cd /root/qcc/experiments/retention_frontier
for _ in $(seq 1 900); do
  grep -q "\[vt3\] done" vt3_runner.log 2>/dev/null && break
  sleep 20
done
source /root/qcc/venv/bin/activate
echo "[lm2] start $(date -Is)"
python lm_nll.py --length 32768 --suffix 256 --budget 1024 \
  --policies obs_last obs_mean recent random \
  --out lm_nll_32k.json > lm_nll_32k.log 2>&1
echo "[lm2] done $(date -Is)"
