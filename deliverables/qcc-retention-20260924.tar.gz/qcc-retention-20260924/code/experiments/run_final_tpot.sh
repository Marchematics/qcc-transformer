#!/usr/bin/env bash
# One window, back to back: matched Full-KV dynamic and both bounded graph budgets.
set -u
cd /root/qcc/experiments/retention_frontier
source /root/qcc/venv/bin/activate
echo "[ft] full-kv dynamic $(date -Is)"
python serve_batch.py --length 131072 --batches 1 --policies full --max-new 32 \
  --out final_tpot_fullkv.json > final_tpot_fullkv.log 2>&1
echo "[ft] bounded graph B=1024 $(date -Is)"
python lean_decode.py --length 131072 --budget 1024 --modes graph \
  --out final_tpot_b1024.json > final_tpot_b1024.log 2>&1
echo "[ft] bounded graph B=4096 $(date -Is)"
python lean_decode.py --length 131072 --budget 4096 --modes graph \
  --out final_tpot_b4096.json > final_tpot_b4096.log 2>&1
echo "[ft] done $(date -Is)"
