#!/bin/bash
# Extend the state-growth measurement to the longest prompts this card can hold,
# now that it is not being shared.
set -u
PY=/root/qcc/venv/bin/python
REPO=/root/qcc/repo/qcc-transformer
LOGS=/root/qcc/experiments/retention_frontier/multimodel
cd "$REPO" || exit 1
export PYTORCH_CUDA_ALLOC_CONF=expandable_segments:True
while pgrep -f "benchmark_retention_multimodel.py" > /dev/null; do sleep 60; done
out=artifacts/bounded-decode-frontier-state-growth-long.json
[ -f "$out" ] && { echo "exists"; exit 0; }
echo "=== state-growth-long start $(date +%H:%M:%S)"
"$PY" benchmarks/benchmark_state_growth.py \
  --lengths 131072 262144 524288 \
  --out "$out" > "$LOGS/state-growth-long.log" 2>&1
echo "=== exit=$? $(date +%H:%M:%S)"
