#!/usr/bin/env bash
# vt: how much surrounding text does the model need to emit the full list?
set -u
cd /root/qcc/experiments/retention_frontier
source /root/qcc/venv/bin/activate
echo "[vt4] start $(date -Is)"
python ruler_frontier.py \
  --ruler-jsonl /home/waas/ruler_a10_v1/ruler_subset.jsonl \
  --tasks vt --policies full lex_obs --budgets 16384 24576 \
  --obs 64 --nsink 4 --pool 7 --dilate 9 --lex-cap 512 --hops 6 \
  --key-chunk 4096 --max-new 128 --prefill-chunk 8192 \
  --out vt_probe4.json > vt_probe4.log 2>&1
echo "[vt4] done $(date -Is)"
