#!/bin/bash
# Keep the measurement queue alive across external interference: if the queue
# process is gone and work remains, restart it.
set -u
QUEUE=/root/qcc/experiments/retention_frontier/run_final_queue2.sh
LOG=/root/qcc/experiments/retention_frontier/multimodel/watch_queue.log
cd /root/qcc/repo/qcc-transformer || exit 1
for round in $(seq 1 200); do
  if ! pgrep -f "final_queue2" > /dev/null; then
    echo "=== restarting queue $(date +%H:%M:%S)" >> "$LOG"
    setsid nohup "$QUEUE" >> /root/qcc/experiments/retention_frontier/multimodel/final_queue2.log 2>&1 < /dev/null &
    sleep 20
  fi
  sleep 600
done
