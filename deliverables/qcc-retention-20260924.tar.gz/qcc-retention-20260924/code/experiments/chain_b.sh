#!/bin/bash
# Wait for the currently running multimodel driver to finish, then run stage set B.
while pgrep -f "run_multimodel.sh llama1b" > /dev/null; do sleep 30; done
exec /root/qcc/experiments/retention_frontier/run_multimodel.sh "$@"
