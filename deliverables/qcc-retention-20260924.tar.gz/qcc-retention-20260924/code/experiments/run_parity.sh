#!/usr/bin/env bash
# Verify CUDA-graph / static-cache decode parity against the dynamic path, and
# re-time with the parity check in place.  Queued after the lex_obs sweep.
set -u
cd /root/qcc/experiments/retention_frontier
source /root/qcc/venv/bin/activate
for _ in $(seq 1 900); do
  if grep -q "RULER lex_obs sweep done" lex_runner.log 2>/dev/null; then break; fi
  sleep 20
done
for p in longctx ruler_frontier serve_batch lean_decode; do
  if pgrep -f "python $p.py" > /dev/null; then echo "[parity] GPU busy, refusing $(date -Is)"; exit 0; fi
done
echo "[parity] start $(date -Is)"
python lean_decode.py --length 32768 --budget 1024 --modes dynamic static graph \
  --out lean_decode_32k_v2.json > lean_decode_32k_v2.log 2>&1
python lean_decode.py --length 131072 --budget 1024 --modes dynamic static graph \
  --out lean_decode_128k_v2.json > lean_decode_128k_v2.log 2>&1
echo "[parity] done $(date -Is)"
