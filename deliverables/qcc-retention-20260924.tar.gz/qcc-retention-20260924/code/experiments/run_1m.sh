#!/usr/bin/env bash
# Wait for any running longctx aggregate to finish, then run the 1M feasibility
# point on the same GPU.  Runs detached; writes to 1m_v1.log / 1m_v1.json.
set -u
cd /root/qcc/experiments/retention_frontier
source /root/qcc/venv/bin/activate
while pgrep -f "[l]ongctx.py" > /dev/null; do sleep 20; done
echo "[runner] aggregate finished, starting 1M point at $(date -Is)"
python longctx.py \
  --lengths 1048576 \
  --policies full obs_last obs_mean \
  --budgets 128 256 \
  --seeds 201 --pairs 1 \
  --prefill-chunk 2048 --max-new 16 \
  --out 1m_v1.json > 1m_v1.log 2>&1
echo "[runner] 1M point done at $(date -Is)"
