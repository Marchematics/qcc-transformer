#!/usr/bin/env bash
# vt with RULER's usual 128-token generation budget, applied to both arms.
set -u
cd /root/qcc/experiments/retention_frontier
for _ in $(seq 1 900); do
  grep -q "\[lm\] done" lm_runner.log 2>/dev/null && break
  sleep 20
done
source /root/qcc/venv/bin/activate
echo "[vt3] start $(date -Is)"
python ruler_frontier.py \
  --ruler-jsonl /home/waas/ruler_a10_v1/ruler_subset.jsonl \
  --tasks vt --policies full lex_obs --budgets 1024 2048 8192 \
  --obs 64 --nsink 96 --pool 7 --dilate 9 --lex-cap 512 --hops 6 \
  --key-chunk 4096 --max-new 128 --prefill-chunk 8192 \
  --out vt_probe3.json > vt_probe3.log 2>&1
echo "[vt3] done $(date -Is)"
