#!/bin/bash
# Quality vs decode-state Pareto at the shipped selection rule: how much of the
# quality survives when the attention-selected filler is cut.
set -u
PY=/root/qcc/venv/bin/python
REPO=/root/qcc/repo/qcc-transformer
LOGS=/root/qcc/experiments/retention_frontier/multimodel
cd "$REPO" || exit 1
export PYTORCH_CUDA_ALLOC_CONF=expandable_segments:True
for script in run_campaign4.sh run_ablation2.sh; do
  while pgrep -f "$script" > /dev/null; do sleep 60; done
done
for budget in "${@:-1024 2048}"; do
  out="artifacts/bounded-decode-frontier-multimodel-llama1b-b$budget.json"
  [ -f "$out" ] && { echo "=== b$budget exists"; continue; }
  free=$(nvidia-smi --query-gpu=memory.free --format=csv,noheader,nounits | head -1)
  [ "$free" -lt 6144 ] && { echo "=== b$budget skipped, $free MiB free"; continue; }
  echo "=== budget $budget start $(date +%H:%M:%S)"
  "$PY" benchmarks/benchmark_retention_multimodel.py --model /root/qcc/models/Llama-3.2-1B-Instruct \
    --budget "$budget" --lex-cap 512 --hops 6 --out "$out" \
    > "$LOGS/multimodel-llama1b-b$budget.log" 2>&1
  echo "=== budget $budget exit=$? $(date +%H:%M:%S)"
done
echo "pareto done $(date +%H:%M:%S)"
