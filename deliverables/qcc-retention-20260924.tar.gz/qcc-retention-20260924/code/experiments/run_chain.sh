#!/usr/bin/env bash
# Sequential chain on the single GPU:
#   1. official RULER with obs_last only (cheap, one-pass scoring) + dilation
#   2. decode-TPOT floor (fair: Full-KV gets the same static/graph path)
#   3. batched serving throughput / memory-limited concurrency
set -u
cd /root/qcc/experiments/retention_frontier
source /root/qcc/venv/bin/activate

echo "[chain] RULER obs_last sweep start $(date -Is)"
python ruler_frontier.py \
  --ruler-jsonl /home/waas/ruler_a10_v1/ruler_subset.jsonl \
  --tasks niah_single_1 niah_multikey_2 niah_multikey_3 vt \
  --policies full obs_last \
  --budgets 512 1024 2048 \
  --obs 64 --nsink 4 --pool 7 --dilate 9 --key-chunk 4096 \
  --max-new 32 --prefill-chunk 8192 \
  --out ruler_v2.json > ruler_v2.log 2>&1
echo "[chain] RULER obs_last sweep done $(date -Is)"

echo "[chain] lean decode 32K $(date -Is)"
python lean_decode.py --length 32768 --budget 1024 --modes dynamic static graph \
  --out lean_decode_32k.json > lean_decode_32k.log 2>&1
echo "[chain] lean decode 128K $(date -Is)"
python lean_decode.py --length 131072 --budget 1024 --modes dynamic static graph \
  --out lean_decode_128k.json > lean_decode_128k.log 2>&1
echo "[chain] lean decode done $(date -Is)"

echo "[chain] batched serving 32K $(date -Is)"
python serve_batch.py --length 32768 --batches 1 2 4 8 16 \
  --policies full obs_last --budget 1024 --max-new 32 \
  --out serving_32k.json > serving_32k.log 2>&1
echo "[chain] batched serving done $(date -Is)"
echo "[chain] complete"
