#!/usr/bin/env bash
# Consistent 128K TPOT set measured back to back on the same (quiet) GPU.
set -u
cd /root/qcc/experiments/retention_frontier
source /root/qcc/venv/bin/activate
echo "[tf] graph B=1024 $(date -Is)"
python lean_decode.py --length 131072 --budget 1024 --modes graph \
  --out tpot_final_b1024.json > tpot_final_b1024.log 2>&1
echo "[tf] graph B=4096 $(date -Is)"
python lean_decode.py --length 131072 --budget 4096 --modes graph \
  --out tpot_final_b4096.json > tpot_final_b4096.log 2>&1
echo "[tf] full-kv baseline $(date -Is)"
python serve_batch.py --length 131072 --batches 1 --policies full --max-new 32 \
  --out tpot_final_fullkv.json > tpot_final_fullkv.log 2>&1
echo "[tf] done $(date -Is)"
