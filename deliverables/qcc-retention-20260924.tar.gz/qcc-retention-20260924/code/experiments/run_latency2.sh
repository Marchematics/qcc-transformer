#!/bin/bash
# Repeats for the matched-optimisation TPOT comparison, retrying while the card
# is contended.  Modes are limited to the two paths that carry the claim.
set -u
PY=/root/qcc/venv/bin/python
REPO=/root/qcc/repo/qcc-transformer
OUT=/root/qcc/experiments/retention_frontier/latency
LOGS=/root/qcc/experiments/retention_frontier/multimodel
mkdir -p "$OUT"; cd "$REPO" || exit 1
export PYTORCH_CUDA_ALLOC_CONF=expandable_segments:True
for length in 32768 131072; do
  for repeat in 1 2 3; do
    json="$OUT/clean-tpot-${length}-r${repeat}.json"
    [ -f "$json" ] && continue
    for attempt in 1 2 3 4 5 6; do
      free=$(nvidia-smi --query-gpu=memory.free --format=csv,noheader,nounits | head -1)
      if [ "$free" -lt 20000 ]; then
        echo "=== length=$length r=$repeat attempt=$attempt waiting, ${free}MiB free $(date +%H:%M:%S)"
        sleep 600; continue
      fi
      echo "=== length=$length r=$repeat attempt=$attempt start $(date +%H:%M:%S)"
      "$PY" benchmarks/benchmark_bounded_decode_tpot_floor.py --length "$length" \
        --budget 4096 --max-new 32 --modes dynamic graph --seed $((7000 + repeat)) \
        --out "$json" > "$LOGS/clean-tpot-${length}-r${repeat}.log" 2>&1
      rc=$?
      "$PY" - "$json" <<'PYEOF' && break
import json, sys
try:
    d = json.load(open(sys.argv[1]))
except Exception:
    sys.exit(1)
ok = "parity_error" not in d and any("tpot_ms" in v for v in d["variants"].values())
sys.exit(0 if ok else 1)
PYEOF
      echo "=== length=$length r=$repeat attempt=$attempt unusable/contended, retrying"
      rm -f "$json"
    done
  done
done
echo "latency2 done $(date +%H:%M:%S)"
